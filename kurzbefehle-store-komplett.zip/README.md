# Kurzbefehle Store

## Architektur

- GitHub Pages: `index.html`, `upload.html`, `admin/index.html`
- Cloudflare Worker: sicherer Upload + Admin-API
- GitHub Repository: speichert Einsendungen und genehmigte Kurzbefehle
- GitHub Actions: validiert Repository-Änderungen

## 1. Repository

Lege dieses Projekt in ein GitHub-Repository. Aktiviere unter Settings → Pages:
**Deploy from a branch → main → / (root)**.

## 2. Cloudflare Worker

Lege einen neuen Worker an und kopiere `worker/worker.js` hinein.

Setze diese Secrets/Variablen:

- `GITHUB_TOKEN`: GitHub Fine-grained Personal Access Token mit `Contents: Read and write` für genau dieses Repository.
- `GITHUB_OWNER`: dein GitHub Benutzername oder deine Organisation.
- `GITHUB_REPO`: Name des Repositorys.
- `ADMIN_PASSWORD`: langes, zufälliges Admin-Passwort.

Die Worker-URL sieht danach etwa so aus:
`https://dein-name.deine-subdomain.workers.dev`

## 3. URLs eintragen

In `upload.html` und `admin/index.html`:

`const API="https://DEIN-WORKER.workers.dev";`

durch deine echte Worker-URL ersetzen.

## 4. Admin

Öffne:

`https://DEIN-USERNAME.github.io/DEIN-REPO/admin/`

Melde dich mit `ADMIN_PASSWORD` an.

## 5. Ablauf

Upload → `submissions/<id>/` → Admin-Prüfung → Genehmigen → Datei nach `shortcuts/` + `shortcuts.json` → Store zeigt sie an.

Ablehnen markiert die Einsendung als `rejected`, ohne sie in den öffentlichen Store zu übernehmen.

## 6. Format

Genehmigte Dateien werden intern nach diesem Muster im Store geführt:

`Name - Beschreibung - Emoji - Creator.shortcut`

Beispiel:

`Wetter Check - Zeigt das aktuelle Wetter - ☀️ - Max.shortcut`

## Sicherheit

Den GitHub-Token niemals in `index.html`, `upload.html` oder `admin/index.html` eintragen. Er gehört ausschließlich in den Worker.
